<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Detalhes do Funcionário</div>

                <div class="card-body">
                    <div class="form-group">
                        <label for="nome">Nome:</label>
                        <input type="text" class="form-control" id="nome" value="<?php echo e($funcionario->nome_completo); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="email">E-mail:</label>
                        <input type="text" class="form-control" id="email" value="<?php echo e($funcionario->email); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="telefone">Telefone:</label>
                        <input type="text" class="form-control" id="telefone" value="<?php echo e($funcionario->telefone); ?>" readonly>
                    </div>

                    <div class="form-group">
                        <label for="cargo">Cargo:</label>
                        <input type="text" class="form-control" id="cargo" value="<?php echo e($funcionario->cargo); ?>" readonly>
                    </div>

                    <?php if($funcionario->foto): ?>
                    <div class="form-group offset-md-4">
                        <label for="foto">Foto:</label><br>
                        <img src="<?php echo e(asset('uploads/' . $funcionario->foto)); ?>" alt="Foto do Funcionário" style="max-width: 300px;">
                    </div>
                    <?php endif; ?>

                    <div class="col-md-6">
                        <a href="<?php echo e(route('funcionarios.index')); ?>" class="btn btn-primary">Voltar</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/funcionarios/show.blade.php ENDPATH**/ ?>