<?php $__env->startSection('title', 'Lista de Alunos'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">

                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <div class="card-header ">

                    <div class="d-flex justify-content-between">
                        <h4>Lista de Alunos</h4>
                        <a href="<?php echo e(route('alunos.create')); ?>" class="btn btn-primary btn-sm float-right">Novo Aluno</a>
                    </div>

                    <br>
                    <form action="<?php echo e(route('alunos.index')); ?>" method="GET" class="form-">
                        <input type="text" id="search" name="search" class="form-control mr-sm-4" placeholder="Buscar alunos">
                        <button type="submit" class="btn btn-outline-primary">Buscar</button>
                    </form>


                </div>

                <div class="card-body">
                    <?php if($alunos->isEmpty()): ?>
                    <p>Não há alunos cadastrados.</p>
                    <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>

                                <th>Nome</th>
                                <th>Email</th>
                                <th>Telefone</th>

                                <th>Sexo</th>
                                <th>Dias Restantes</th>
                                <th>Status</th>
                                <th>Ver Mais</th> <!-- Nova coluna para as ações -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr style="<?php echo e($aluno->dias_restantes <= 5 ? 'color:red;' : ''); ?>">

                                <td><?php echo e($aluno->nome); ?></td>
                                <td><?php echo e($aluno->email); ?></td>
                                <td><?php echo e($aluno->telefone); ?></td>

                                <td><?php echo e($aluno->sexo == 'M' ? 'Masculino' : 'Feminino'); ?></td>
                                <td><?php echo e($aluno->dias_restantes); ?> dias</td>
                                <td><?php echo e($aluno->matricula_ativa); ?></td>
                                <td>
                                    <?php if($aluno->matricula_ativa == 'ativa'): ?>
                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#confirmarTrancamento<?php echo e($aluno->id); ?>">
                                    <i class="fas fa-lock"></i> Trancar Matrícula
                                    </button>
                                    <!-- Modal de confirmação para trancar -->
                                    <div class="modal fade" id="confirmarTrancamento<?php echo e($aluno->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Confirmar Trancamento</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    Tem certeza de que deseja trancar a matrícula do aluno <?php echo e($aluno->nome); ?>?
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                                    <form action="<?php echo e(route('alunos.trancarMatricula', $aluno->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-danger">Confirmar</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php elseif($aluno->matricula_ativa == 'trancado'): ?>
                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#confirmarDestrancamento<?php echo e($aluno->id); ?>">
                                    <i class="fas fa-unlock"></i>Destrancar Matrícula
                                    </button>
                                    <!-- Modal de confirmação para destrancar -->
                                    <div class="modal fade" id="confirmarDestrancamento<?php echo e($aluno->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Confirmar Destrancamento</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    Tem certeza de que deseja destrancar a matrícula do aluno <?php echo e($aluno->nome); ?>?
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                                    <form action="<?php echo e(route('alunos.destrancarMatricula', $aluno->id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-success">Confirmar</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('alunos.show', $aluno->id)); ?>" class="btn btn-info btn-sm">Detalhes</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Biblioteca JavaScript do Bootstrap -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/alunos/index.blade.php ENDPATH**/ ?>