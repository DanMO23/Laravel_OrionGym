<!-- resources/views/compra/historico.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
        <h1>Histórico de Compras</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>Aluno</th>
                    <th>Pacote</th>
                    <th>Descrição</th>
                    <th>Validade do Pacote</th>
                    <th>Data da Compra</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($compra->aluno->nome); ?></td>
                    <td><?php echo e($compra->pacote->nome_pacote); ?></td>
                    <td><?php echo e($compra->descricao_pagamento); ?></td>
                    <td><?php echo e($compra->pacote->validade); ?> dias restantes</td>
                    <td><?php echo e($compra->created_at->format('d/m/Y H:i:s')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/compra/historico.blade.php ENDPATH**/ ?>