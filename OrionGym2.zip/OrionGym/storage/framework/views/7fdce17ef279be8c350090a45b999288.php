<?php $__env->startSection('header-user', 'Detalhes do Professor'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <?php if($professor->foto): ?>
                            <div class="form-group">
                        <label for="foto">Foto:</label><br>
                        <img src="<?php echo e(asset('uploads/' . $professor->foto)); ?>" alt="Foto do Funcionário" style="max-width: 300px;">
                    </div>
                            <?php else: ?>
                            <p>Foto não disponível</p>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-8">
                            <p><strong>Nome:</strong> <?php echo e($professor->nome_completo); ?></p>
                            <p><strong>Email:</strong> <?php echo e($professor->email); ?></p>
                            <p><strong>Telefone:</strong> <?php echo e($professor->telefone); ?></p>
                            <p><strong>Cargo:</strong> <?php echo e($professor->cargo); ?></p>
                            <p><strong>Endereço:</strong> <?php echo e($professor->endereco); ?></p>

                        </div>
                        <div class="col-md-12">
                            <a href="<?php echo e(route('professores.index')); ?>" class="btn btn-primary">Voltar</a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/professores/show.blade.php ENDPATH**/ ?>