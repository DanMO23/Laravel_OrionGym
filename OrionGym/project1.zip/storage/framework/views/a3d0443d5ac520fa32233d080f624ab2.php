<?php $__env->startSection('header-user', 'Lista de Pacotes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card">

                <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
                <?php endif; ?>
                <div class="card-header">Lista de Pacotes</div>

                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <a href="<?php echo e(route('pacotes.create')); ?>" class="btn btn-primary mb-3">Criar Novo Pacote</a>
                        </div>
                    </div>

                    <?php if($pacotes->isEmpty()): ?>
                    <p>Nenhum pacote encontrado.</p>
                    <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Valor</th>
                                <th>Validade</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pacotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pacote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pacote->nome_pacote); ?></td>
                                <td><?php echo e($pacote->valor); ?></td>
                                <td><?php echo e($pacote->validade); ?> dias</td>
                                <td>

                                    <a href="<?php echo e(route('pacotes.edit', $pacote->id)); ?>" class="btn btn-sm btn-primary">Editar</a>
                                    <form action="<?php echo e(route('pacotes.destroy', $pacote->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Tem certeza que deseja excluir este pacote?')">Excluir</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/pacotes/index.blade.php ENDPATH**/ ?>