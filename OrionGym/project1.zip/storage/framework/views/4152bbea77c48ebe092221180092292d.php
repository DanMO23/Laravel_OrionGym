<?php $__env->startSection('header-user', 'Lista de Professores'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if($professores->isEmpty()): ?>
                    <p>Nenhum professor encontrado.</p>
                    <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th></th>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>Telefone</th>
                                <th>Cargo</th>
                                <th>Tipo</th>
                                <th>Ações</th>
                                <!-- Adicione mais colunas conforme necessário -->
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $professores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $professor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($professor->foto): ?>
                                    <img src="<?php echo e(asset('uploads/' . $professor->foto)); ?>" alt="Foto do Professor" style="max-width: 100px;">
                                    <?php else: ?>
                                    <p>"Foto não disponível"</p>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($professor->nome_completo); ?></td>
                                <td><?php echo e($professor->email); ?></td>
                                <td><?php echo e($professor->telefone); ?></td>
                                <td><?php echo e($professor->cargo); ?></td>
                                <td><?php echo e($professor->tipo); ?></td>
                                <td>
                                    <a href="<?php echo e(route('professores.show', $professor->id)); ?>" class="btn btn-info btn-sm">Detalhes</a>
                                   
                                    <form action="<?php echo e(route('professores.destroy', $professor->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este professor?')">Excluir</button>
                                    </form>
                                <!-- Adicione mais colunas conforme necessário -->
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/professores/index.blade.php ENDPATH**/ ?>