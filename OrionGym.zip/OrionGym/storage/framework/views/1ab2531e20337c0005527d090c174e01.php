<?php $__env->startSection('title', 'Detalhes do Aluno'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Detalhes do Aluno</div>

                <div class="card-body">
                    <div class="form-group row">
                        <label for="nome" class="col-md-4 col-form-label text-md-right">Nome:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->nome); ?></p>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="email" class="col-md-4 col-form-label text-md-right">Email:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->email); ?></p>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="telefone" class="col-md-4 col-form-label text-md-right">Telefone:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->telefone); ?></p>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="data_nascimento" class="col-md-4 col-form-label text-md-right">Data de Nascimento:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->data_nascimento); ?></p>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="cpf" class="col-md-4 col-form-label text-md-right">CPF:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->cpf); ?></p>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="sexo" class="col-md-4 col-form-label text-md-right">Sexo:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->sexo); ?></p>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="endereco" class="col-md-4 col-form-label text-md-right">Endereço:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->endereco); ?></p>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="bairro" class="col-md-4 col-form-label text-md-right">Status da Matricula:</label>
                        <div class="col-md-6">
                            <p><?php echo e($aluno->matricula_ativa); ?></p>
                        </div>
                    <br>
                    <!-- Adicione mais campos conforme necessário -->

                    <div class="form-group">
                        <div class="col-md-6 offset-md-4">
                            <!-- Botão para Editar -->
                            <a href="<?php echo e(route('alunos.edit', $aluno->id)); ?>" class="btn btn-primary mr-2">Editar</a>

                            <!-- Botão para Excluir com Confirmação -->
                            <form action="<?php echo e(route('alunos.destroy', $aluno->id)); ?>" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir este aluno?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger mr-2">Excluir</button>
                            </form>
                        </div>
                        <div class="col-md-6 offset-md-4">
                            <a href="<?php echo e(route('alunos.index')); ?>" class="btn btn-primary">Voltar</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/alunos/show.blade.php ENDPATH**/ ?>