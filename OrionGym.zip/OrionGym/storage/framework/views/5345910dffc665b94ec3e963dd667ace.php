Essa é minha view do alunos.trancar



<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Detalhes do Aluno')); ?></div>

                <div class="card-body">
                    <p><strong>Nome:</strong> <?php echo e($aluno->nome); ?></p>
                    <p><strong>Email:</strong> <?php echo e($aluno->email); ?></p>
                    <p><strong>Sexo:</strong> <?php echo e($aluno->sexo == 'M' ? 'Masculino' : 'Feminino'); ?></p>

                    <p><strong>Telefone:</strong> <?php echo e($aluno->telefone); ?></p>
                    <p><strong>Endereço:</strong> <?php echo e($aluno->endereco); ?></p>
                    <!-- Adicione aqui mais informações do aluno, se necessário -->

                    <form action="<?php echo e(route('alunos.confirmarTrancamento', $aluno->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">
                            Confirmar Trancamento
                            <i class="fa fa-lock"></i> <!-- Ícone de cadeado -->
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


E estas são as funções do alunoController
public function confirmarTrancamento($id)
{
    // Lógica para trancar a matrícula do aluno com o ID fornecido
    // Por exemplo:
    $aluno = Aluno::findOrFail($id);
    $aluno->matricula_ativa = 'inativa';
    $aluno->save();

    return redirect()->route('alunos.index')->with('success', 'Matrícula do aluno trancada com sucesso.');
}



public function trancarMatricula(Aluno $aluno)
{
    return view('alunos.trancar', compact('aluno'));
}


Considerando isso, o que preciso arrumar?
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/alunos/trancar.blade.php ENDPATH**/ ?>