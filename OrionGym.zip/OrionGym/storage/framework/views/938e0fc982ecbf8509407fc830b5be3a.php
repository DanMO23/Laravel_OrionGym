<?php $__env->startSection('title', 'Editar Pacote'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Editar Pacote</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('pacotes.update', $pacote->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>

                        <div class="form-group">
                            <label for="nome">Nome do Pacote</label>
                            <input type="text" name="nome" id="nome" class="form-control" value="<?php echo e(old('nome', $pacote->nome)); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="valor">Valor do Pacote</label>
                            <input type="number" name="valor" id="valor" class="form-control" value="<?php echo e(old('valor', $pacote->valor)); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="validade">Validade do Pacote(em dias)</label>
                            <input type="number" name="validade" id="validade" class="form-control" value="<?php echo e(old('validade', $pacote->validade)); ?>" required>
                        </div>

                        <a href="<?php echo e(route('pacotes.index')); ?>" class="btn btn-secondary">Voltar</a>
                        <button type="submit" class="btn btn-primary">Atualizar Pacote</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/pacotes/edit.blade.php ENDPATH**/ ?>