<!-- resources/views/compra/create.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
    
        <h2>Comprar Pacote</h2>
        <form action="<?php echo e(route('compra.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="aluno">Selecione o Aluno:</label>
                <select name="aluno" id="aluno" class="form-control">
                    <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($aluno->id); ?>"><?php echo e($aluno->nome); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="pacote">Selecione o Pacote:</label>
                <select name="pacote" id="pacote" class="form-control">
                    <?php $__currentLoopData = $pacotes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pacote): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pacote->id); ?>"><?php echo e($pacote->nome_pacote); ?> - R$ <?php echo e($pacote->valor); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="descricao_pagamento">Descrição do Pagamento:</label>
                <textarea name="descricao_pagamento" id="descricao_pagamento" class="form-control" rows="3"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Comprar Pacote</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dan23/Documentos/GitHub/Laravel_OrionGym/OrionGym/resources/views/compra/create.blade.php ENDPATH**/ ?>